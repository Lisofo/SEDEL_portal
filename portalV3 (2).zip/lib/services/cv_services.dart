import 'package:dio/dio.dart';
import 'package:portal_maqueta/models/clients.dart';
import 'package:portal_maqueta/models/constanciasVisita.dart';
import 'package:portal_maqueta/models/servicios_contratados.dart';

class PortalServices {
  final _dio = Dio();
  final _dio2 = Dio();
  Future<List<DocPortal>> getDocumentos(
      String codCliente, String categ, String orden) async {
    try {
      print(codCliente);
      print(categ);
      var resp = await _dio.request(
          'http://sap.com.uy:30010/clientes/$codCliente/$categ?orden=$orden',
          options: Options(method: 'GET'));

      final List<dynamic> docList = resp.data;
      return docList.map((obj) => DocPortal.fromJson(obj)).toList();
    } catch (e) {
      print(e);
      return [];
    }
  }

  Future<List<ClientePortal>> getClientes(String uId, String token) async {
    try {
      print(uId);
      var headers = {'Authorization': token};
      print('http://sap.com.uy:30009/api/v1/usuarios/$uId/clientes');
      var resp = await _dio2.request(
        'http://sap.com.uy:30009/api/v1/usuarios/$uId/clientes',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> clientList = resp.data;
      return clientList.map((obj) => ClientePortal.fromJson(obj)).toList();
    } catch (e) {
      print(e);
      return [];
    }
  }
  Future<List<ServiciosContratados>> getServicios(String clienteId, String token) async {
    try {
      print(clienteId);
      var headers = {'Authorization': token};
      print('http://sap.com.uy:30009/api/v1/clientes/$clienteId/servicios');
      var resp = await _dio2.request(
        'http://sap.com.uy:30009/api/v1/clientes/$clienteId/servicios',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> serviceList = resp.data;
      return serviceList.map((obj) => ServiciosContratados.fromJson(obj)).toList();
    } catch (e) {
      print(e);
      return [];
    }
  }
}
