import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:portal_maqueta/providers/menu_providers.dart';
import 'package:provider/provider.dart';

class LoginDesktop extends StatefulWidget {
  const LoginDesktop({super.key});

  @override
  State<LoginDesktop> createState() => _LoginDesktopState();
}

class _LoginDesktopState extends State<LoginDesktop> {
  var isObscured;
  final _formKey = GlobalKey<FormState>();
  final passwordFocusNode = FocusNode();
  final userFocusNode = FocusNode();
  String user = '';
  String pass = '';
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  void login(String login, password) async {
    try {
      Map data = {
        'login': login,
        'password': password,
      };
      String body = json.encode(data);

      http.Response response = await http.post(
        Uri.parse('http://sap.com.uy:30009/api/auth/login'),
        body: body,
        headers: {"Content-Type": "application/json"},
      );
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body.toString());
        print('login successfully');
        Provider.of<MenuProvider>(context, listen: false)
            .setToken(data['token'].toString());
        Provider.of<MenuProvider>(context, listen: false)
            .setUId(data['uid'].toString());
        print(data['token']);
        print(data['uid']);
        Navigator.pushNamed(context, 'seleccionCliente');
      } else {
        print('failed');
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    isObscured = true;
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.962,
                width: MediaQuery.of(context).size.width / 2,
                child: Image.asset(
                  'images/logo.png',
                ),
              ),
              Expanded(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 18),
                  padding: const EdgeInsets.symmetric(horizontal: 45),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Bienvenido',
                        style: GoogleFonts.inter(
                            fontSize: 28,
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Inicia Sesion en tu cuenta',
                        style: GoogleFonts.inter(
                            fontSize: 17,
                            color: Color.fromARGB(255, 52, 120, 62),
                            fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 35),
                      Form(
                          key: _formKey,
                          child: TextFormField(
                            controller: usernameController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                    borderRadius: BorderRadius.circular(20)),
                                fillColor: Colors.white,
                                filled: true,
                                prefixIcon: Icon(Icons.person),
                                prefixIconColor:
                                    Color.fromARGB(255, 41, 146, 41),
                                hintText: 'Ingrese su usuario'),
                          )),
                      const SizedBox(height: 20),
                      Form(
                          child: TextFormField(
                        controller: passwordController,
                        obscureText: isObscured,
                        focusNode: passwordFocusNode,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderSide: BorderSide(),
                                borderRadius: BorderRadius.circular(20)),
                            fillColor: Colors.white,
                            filled: true,
                            prefixIcon: Icon(Icons.lock),
                            prefixIconColor: Color.fromARGB(255, 41, 146, 41),
                            suffixIcon: IconButton(
                              padding: EdgeInsetsDirectional.only(end: 12.0),
                              icon: isObscured
                                  ? Icon(
                                      Icons.visibility_off,
                                      color: Colors.black,
                                    )
                                  : Icon(Icons.visibility, color: Colors.black),
                              onPressed: () {
                                setState(() {
                                  isObscured = !isObscured;
                                });
                              },
                            ),
                            hintText: 'Ingrese su contraseña'),
                      )),
                      SizedBox(
                        height: 40,
                      ),
                      ElevatedButton(
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStatePropertyAll(Colors.white),
                              elevation: MaterialStatePropertyAll(10),
                              shape: MaterialStatePropertyAll(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.horizontal(
                                          left: Radius.circular(50),
                                          right: Radius.circular(50))))),
                          onPressed: () {
                            login(usernameController.text.toString(),
                                passwordController.text.toString());
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.5),
                            child: Text(
                              'Iniciar Sesión',
                              style: TextStyle(
                                  color: Color.fromARGB(255, 52, 120, 62),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25),
                            ),
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            color: Color.fromARGB(255, 52, 120, 62),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 16, right: 16, top: 10, bottom: 5),
              child: Text(
                'Número de teléfono: 23623375 / +598 98 409 523                Correo Electrónico: sedel@sedel.com.uy',
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          )
        ],
      ),
    );
  }
}
