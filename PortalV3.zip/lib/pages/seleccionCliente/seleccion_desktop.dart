import 'package:flutter/material.dart';
import 'package:portal_maqueta/models/clients.dart';
import 'package:portal_maqueta/models/servicios_contratados.dart';
import 'package:portal_maqueta/providers/menu_providers.dart';
import 'package:provider/provider.dart';

class SeleccionDesktop extends StatefulWidget {
  const SeleccionDesktop({super.key});

  @override
  State<SeleccionDesktop> createState() => _SeleccionDesktopState();
}

class _SeleccionDesktopState extends State<SeleccionDesktop> {
  List<Client> clientes = [
    Client(
      clienteId: 1,
      codCliente: '3023',
      ruc: '123123',
      nombre: 'Jose Luis',
      direccion: 'direccion',
      departamento: 'Montevideo',
      telefono1: '+59898372886',
      telefono2: '',
      fax: '',
      email: 'correoejemplo@gmail.com',
      localidad: 'Montevideo',
      departamentoId: 1,
      servicios: [
        ServiciosContratados(
            codServicio: '01', descripcion: 'Monitoreo y control de aves')
      ],
    ),
    Client(
      clienteId: 2,
      codCliente: '3297',
      ruc: '123123',
      nombre: 'Miguel Ohara',
      direccion: 'direccion',
      departamento: 'Montevideo',
      telefono1: '+59898372886',
      telefono2: '',
      fax: '',
      email: 'correoejemplo@gmail.com',
      localidad: 'Montevideo',
      departamentoId: 1,
      servicios: [
        ServiciosContratados(
            codServicio: '01', descripcion: 'Monitoreo y control de aves'),
        ServiciosContratados(
            codServicio: '02', descripcion: 'Monitoreo y control de abejas'),
        ServiciosContratados(
            codServicio: '03', descripcion: 'Monitoreo y control de abejas'),
        ServiciosContratados(
            codServicio: '04', descripcion: 'Monitoreo y control de arañas'),
        ServiciosContratados(
            codServicio: '05', descripcion: 'Monitoreo y control de aves'),
        ServiciosContratados(
            codServicio: '06',
            descripcion: 'Monitoreo y control de avispas/lechiguanas'),
        ServiciosContratados(
            codServicio: '07',
            descripcion: 'Monitoreo y control de coleopteros'),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
              color: Color.fromARGB(255, 52, 120, 62),
              child: Row(children: [
                Image.asset('images/logoPortal.png'),
              ])),
          SizedBox(
            height: 40,
          ),
          Expanded(
              child: ListView.separated(
            itemCount: clientes.length,
            itemBuilder: (context, index) {
              final _clientes = clientes[index];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 300),
                child: ListTile(
                  title: Text(
                    _clientes.nombre,
                    textAlign: TextAlign.center,
                  ),
                  subtitle: Text(
                    _clientes.codCliente,
                    textAlign: TextAlign.center,
                  ),
                  onTap: () {
                    context.read<MenuProvider>().setClient(_clientes);
                    Navigator.pushNamed(context, 'panelClientes');
                  },
                ),
              );
            },
            separatorBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 300),
                child: Divider(
                  thickness: 3,
                  color: Colors.green,
                ),
              );
            },
          ))
        ],
      ),
    );
  }
}
