import 'package:flutter/material.dart';
import 'package:portal_maqueta/models/clients.dart';
import 'package:portal_maqueta/models/servicios_contratados.dart';
import 'package:portal_maqueta/providers/menu_providers.dart';
import 'package:provider/provider.dart';

class SeleccionMobile extends StatefulWidget {
  const SeleccionMobile({super.key});

  @override
  State<SeleccionMobile> createState() => _SeleccionMobileState();
}

class _SeleccionMobileState extends State<SeleccionMobile> {
  List<Client> clientes = [
    Client(
      clienteId: 1,
      codCliente: '3023',
      ruc: '123123',
      nombre: 'Jose Luis',
      direccion: 'direccion',
      departamento: 'Montevideo',
      telefono1: '+59898372886',
      telefono2: '',
      fax: '',
      email: 'correoejemplo@gmail.com',
      localidad: 'Montevideo',
      departamentoId: 1,
      servicios: [
        ServiciosContratados(
            codServicio: '01', descripcion: 'Monitoreo y control de aves')
      ],
    ),
    Client(
      clienteId: 2,
      codCliente: '3297',
      ruc: '123123',
      nombre: 'Miguel Ohara',
      direccion: 'direccion',
      departamento: 'Montevideo',
      telefono1: '+59898372886',
      telefono2: '',
      fax: '',
      email: 'correoejemplo@gmail.com',
      localidad: 'Montevideo',
      departamentoId: 1,
      servicios: [
        ServiciosContratados(
            codServicio: '01', descripcion: 'Monitoreo y control de aves'),
        ServiciosContratados(
            codServicio: '02', descripcion: 'Monitoreo y control de abejas'),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 52, 120, 62),
          title: Image.asset('images/logoPortal.png'),
          automaticallyImplyLeading: false,
        ),
        backgroundColor: Color.fromARGB(255, 52, 120, 62),
        body: Container(
          color: Colors.white,
          child: Column(
            children: [
              SizedBox(
                height: 10,
              ),
              Expanded(
                  child: ListView.separated(
                itemCount: clientes.length,
                itemBuilder: (context, index) {
                  final _clientes = clientes[index];
                  return ListTile(
                    leading: Icon(Icons.person),
                    title: Text(
                      _clientes.nombre,
                      textAlign: TextAlign.center,
                    ),
                    subtitle: Text(
                      _clientes.codCliente,
                      textAlign: TextAlign.center,
                    ),
                    onTap: () {
                      context.read<MenuProvider>().setClient(_clientes);
                      Navigator.pushNamed(context, 'panelClientes');
                    },
                  );
                },
                separatorBuilder: (BuildContext context, int index) {
                  return Divider(
                    thickness: 3,
                    color: Colors.green,
                  );
                },
              ))
            ],
          ),
        ),
      ),
    );
  }
}
