import 'package:dio/dio.dart';
import 'package:portal_maqueta/models/constanciasVisita.dart';

class PortalServices {
  final _dio = Dio();
  Future<List<DocPortal>> getDocumentos(String codCliente, String categ, String orden) async {
    try {
      print(codCliente);
      print(categ);
      var resp = await _dio.request(
          'http://sap.com.uy:30010/clientes/$codCliente/$categ?orden=$orden',
          options: Options(method: 'GET'));

      final List<dynamic> docList = resp.data;
      return docList.map((obj) => DocPortal.fromJson(obj)).toList();
    } catch (e) {
      print(e);
      return [];
    }
  }
}
