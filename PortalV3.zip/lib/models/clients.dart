import 'package:portal_maqueta/models/servicios_contratados.dart';

class Client {
  late int clienteId;
  late String codCliente;
  late String ruc;
  late String nombre;
  late String direccion;
  late String departamento;
  late String telefono1;
  late String telefono2;
  late String fax;
  late String email;
  late String localidad;
  late int departamentoId;
  late List<ServiciosContratados> servicios;

  Client({
    required this.clienteId,
    required this.codCliente,
    required this.ruc,
    required this.nombre,
    required this.direccion,
    required this.departamento,
    required this.telefono1,
    required this.telefono2,
    required this.fax,
    required this.email,
    required this.localidad,
    required this.departamentoId,
    required this.servicios,
  });

  // static Client fromJson(Map json) => Client(
  //       clienteId: json["ClienteId"] as int? ?? 0,
  //       codCliente: json["CodCliente"] as String? ?? '',
  //       ruc: json["Ruc"] as String? ?? '',
  //       nombre: json["Nombre"] as String? ?? '',
  //       direccion: json["Direccion"] as String? ?? '',
  //       departamento: json["Departamento"] as String? ?? '',
  //       telefono1: json["Telefono1"] as String? ?? '',
  //       telefono2: json["Telefono2"] as String? ?? '',
  //       fax: json["Fax"] as String? ?? '',
  //       email: json["Email"] as String? ?? '',
  //       localidad: json["Localidad"] as String? ?? '',
  //       departamentoId: json["DepartamentoId"] as int? ?? 0,

  //     );

  Client.empty() {
    clienteId = 0;
    codCliente = '';
    ruc = '';
    nombre = '';
    direccion = '';
    departamento = '';
    telefono1 = '';
    telefono2 = '';
    fax = '';
    email = '';
    localidad = '';
    departamentoId = 0;
    servicios = [];
  }

  @override
  String toString() {
    return 'Instance of Client: $nombre';
  }
}
