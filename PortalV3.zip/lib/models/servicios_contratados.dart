class ServiciosContratados {
  late String codServicio;
  late String descripcion;

  ServiciosContratados({
    required this.codServicio,
    required this.descripcion,
  });

  ServiciosContratados.empty() {
    codServicio = '';
    descripcion = '';
  }
}
